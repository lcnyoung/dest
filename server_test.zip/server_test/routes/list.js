var express = require('express');
var router = express.Router();
var sql = require('../sql/conn');

router.get('/', function (req, res, next) {
    sql.selectAll('sales',function(data){
        console.log(data);
        res.render('list', {
            val: data
        });
        
    })
    
});

module.exports = router;