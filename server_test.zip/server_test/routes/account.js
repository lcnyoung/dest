var express = require('express');
var router = express.Router();
var sql = require('../sql/conn');

router.get('/', function (req, res, next) {
	res.render('account', {
		title: 'Account'
	});
});


router.post('/',function(req,res){
    if(req.body.style_ == 'check2'){
        sql.select('show',{
			"userMobi": req.body.userMobi,
            "userPwd": req.body.userPwd
		}, function (data) {
            console.log(data);
			if (data.length > 0) {
				res.send("true");
			} else {
				res.send("false");
			}
		})
        
    }
})

module.exports = router;