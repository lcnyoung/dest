var express = require('express');
var router = express.Router();
var sql = require('../sql/conn');

router.get('/', function (req, res, next) {
	res.render('modify', {
		title: 'Modify'
	});
});

router.post('/',function(req,res){
    if(req.body.style_ == 'check3'){
        sql.select('show',{
			"userMobi": req.body.userMobi,
            "userPwd": req.body.userPwd
		}, function (data) {
            console.log(data);
			if (data.length > 0) {
				res.send("true");
			} else {
				res.send("false");
			}
		}) 
    }else if (req.body.style_ == 'update_') {
		sql.update({
            'userMobi':req.body.userMobi,
		}, {
			$set: {
            
				'userPwd': req.body.newPwd
			}
		})
	}
})
module.exports = router;
