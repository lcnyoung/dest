var express = require('express');
var router = express.Router();
var sql = require('../sql/conn');

router.get('/', function (req, res, next) {
	res.render('submit', {
		name: req.query._name
	});
});


router.post('/',function(req,res,next){
    if(req.body.style == 'select_'){
        sql.select('sales',{
            "name": req.body.name
        },function(data){
            console.log(data);
            res.send(data);
        })
    }
        
})
module.exports = router;
