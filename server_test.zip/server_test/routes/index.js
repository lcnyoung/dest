var express = require('express');
var router = express.Router();
var sql = require('../sql/conn');
/* GET home page. */
router.get('/', function (req, res, next) {
	res.render('index', {
		title: 'Express'
	});
});








//all();
//
//function all() {
//	var data_;
//	sql.selectAll(function (data) {
//		data_ = data;
//	});
//	router.get('/', function (req, res, next) {
//		res.render('index', {
//			key_: data_,
//			tit: '测试'
//		});
//	});
//}



router.post('/', function (req, res) {
	if (req.body.style_ == 'check') {
		sql.select('show',{
			"userMobi": req.body.userMobi
		}, function (data) {
            console.log(data);
			if (data.length > 0) {
				res.send("true");
			} else {
				res.send("false");
			}
		})
	} else if (req.body.style_ == 'ins') {
		sql.insert({
			"userMobi": req.body.userMobi,
			"userPwd": req.body.userPwd,
            "userCoin": req.body.userCoin
		})
	} else if (req.body.style == 'del_') {
		sql.del({
			"userName": req.body.username
		})
	} else if (req.body.style == 'update_') {
		sql.update({
			'userName': req.body.username
		}, {
			$set: {
				'userName': req.body.newname
			}
		})
	}
})
module.exports = router;
