var mongo = require("mongodb");
var server = mongo.Server("localhost",27017,{auto_reconnect:true});
var db = new mongo.Db("data",server,{safe:true});


exports.selectAll = selectAll;
exports.select = select;
exports.insert = insert;
exports.del = del;
exports.update= update;

function selectAll(database,fun){  //全部查询
	db.open(function (err,db) {
		db.collection(database, function (err,collection) {
			collection.find({}).toArray(function(err,docs){
				    fun(docs);
				    db.close();
			});
		});
	});	
}


function select(coll,att,fun){  //根据条件查询
	db.open(function (err,db) {
		db.collection(coll, function (err,collection) {
			collection.find(att).toArray(function(err,docs){
					fun(docs);
					db.close();
			});
		});
	});	
}


function insert(data){  //增加一条数据
	db.open(function (err,db) {
		db.collection("show", function (err,collection) {
			collection.insert(data, function(err, result){
				console.log('insert success !');
				db.close();
			})
		});
	});	
}


function del(data){  //删除一条数据
	db.open(function (err,db) {
		db.collection("show", function (err,collection) {
			collection.remove(data, function(err, result){
				console.log('del success !');
				db.close();
			})
		});
	});	
}


function update(data1,data2){  //修改一条数据
	db.open(function (err,db) {
		db.collection("show", function (err,collection) {
			collection.update(data1,data2,function(err, result){
				console.log('updata success !');
				db.close();
			})
		});
	});	
}




