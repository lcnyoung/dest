$(function(){
    $(document).ready(function(){
        var name = $('#billname').text();
        console.log(name);
        $.post('/submit',{
            name : name,
            style : 'select_'
        },function(data){
            console.log(data);
            $('#un-price').text(data[0].price);
            $('.total-price').text(data[0].price);
            $('.all-money').text(data[0].price);
        })
    })
    var price = $('#un-price').text();
    $('.plus').on('click',function(){
        var i = parseInt($('.count-inp').val());
        i++;
        $('.count-inp').val(i);
        $('.total-price,.all-money').text(Number(i * price).toFixed(2));
    })
    $('.minus').on('click',function(){
        var m = parseInt($('.count-inp').val());
        if(m>1 )
        m--;
        $('.count-inp').val(m);
        $('.total-price,.all-money').text(Number(m * price).toFixed(2));
    })
    $('.count-inp').on('input change',function(){
        var num = $('.count-inp').val();
        $('.total-price,.all-money').text(Number(num * price).toFixed(2));
    })
})