$(function(){
    $('.btn-login').on('click',function(){
        var acc = $('#acc').val();
        var pass = $('#pass').val();
        if(acc !== '' && pass !== '') {
            $.post('/account',{
                userMobi: acc,
                userPwd: pass,
                style_: 'check2'
            },function(data){
                if(data == 'true'){
                   $('.warning').fadeIn().html('登陆成功').fadeOut(3000); 
                   setTimeout(function(){
                       location.href = "http://127.0.0.1:3000/list"
                   },3000)
                } else if(data == 'false'){
                   $('.warning').fadeIn().html('账号或密码错误').fadeOut(3000); 
                }
            })
        } else{
            $('.warning').fadeIn().html('账号或密码错误').fadeOut(3000); 
        }
    });
    $('.close').on('click',function(){
        $('.notice').fadeOut();
    })
})