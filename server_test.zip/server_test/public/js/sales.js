$(function(){
    $(document).ready(function(){
        var name = $('.sale-title').text();
        console.log(name);
        $.post('/sale',{
            name:name,
            style: "select_"
        },function(data){
            console.log(data);
            $('.sale-des').text(data[0].des);
            $('.soldcount').text(data[0].sold);
            $('.saleshow').css({background:'url('+data[0].url+')','background-size':'cover'})
            $('.highlight').text(data[0].price)
        })
    })
        
    $('.btn-buy').on('click',function(){
        location.href = 'http://127.0.0.1:3000/submit?_name='+ $('.sale-title').text();
    })
    
})