$(function(){
    for(var i =0;i< $('.rec-shops').length ;i++){
        $('.rec-shops').eq(i).on('click',function(){
           var name = $(this).children('.shops-info').children('.shopname').children('b').html();
            location.href = 'http://127.0.0.1:3000/sale?_id=' + name;
            
        })  
    }
    
    
    
})